﻿using System.Windows;
using System.Collections.Generic;

using Cellbi.SvSlideShow;

namespace SampleProductTour
{
  public class PatternList : DependencyObject
  {
    const int RepeatCount = 3;

    int repeatIndex = 0;
    int index = 0;
    List<ISlideShowPattern> items;

    public PatternList()
    {
      items = new List<ISlideShowPattern>();
    }

    public ISlideShowPattern GetNextPattern()
    {
      if (repeatIndex >= RepeatCount)
      {
        index++;
        repeatIndex = 0;
      }
      repeatIndex++;

      if (index >= items.Count)
        index = 0;
      return items[index];
    }

    public List<ISlideShowPattern> Items
    {
      get { return items; }
    }
  }
}