﻿using System;
using System.ComponentModel;
using System.Collections.Generic;

namespace SampleProductTour
{
  public class Product : INotifyPropertyChanged
  {
    string name;
    List<ProductImage> images;

    public Product()
    {
      images = new List<ProductImage>();
    }

    protected virtual void OnPropertyChanged(string propertyName)
    {
      if (PropertyChanged != null)
        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
    }
    
    public event PropertyChangedEventHandler PropertyChanged;

    public void AddProductImage(string source)
    {
      images.Add(new ProductImage(source));
    }

    public string Name
    {
      get { return name; }
      set
      {
        name = value;
        OnPropertyChanged("Name");
      }
    }
    public IEnumerable<ProductImage> Images
    {
      get { return images; }
    }
  }

  public class ProductImage : INotifyPropertyChanged
  {
    string imageSource;

    public ProductImage(string source)
    {
      imageSource = source;
    }

    protected virtual void OnPropertyChanged(string propertyName)
    {
      if (PropertyChanged != null)
        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
    }

    public event PropertyChangedEventHandler PropertyChanged;

    public string ImageSource
    {
      get { return imageSource; }
      set
      {
        imageSource = value;
        OnPropertyChanged("ImageSource");
      }
    }
  }
}