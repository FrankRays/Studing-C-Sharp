﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SampleProductTour
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();

      Loaded += new RoutedEventHandler(ehLoaded);
    }

    // handlers ...
    void ehLoaded(object sender, RoutedEventArgs e)
    {
      btnLeft.MouseLeftButtonDown += new MouseButtonEventHandler(btnLeft_MouseLeftButtonDown);
      btnLeft.MouseEnter += new MouseEventHandler(btnRight_MouseEnter);
      btnLeft.MouseLeave += new MouseEventHandler(btnRight_MouseLeave);

      btnRight.MouseLeftButtonDown += new MouseButtonEventHandler(btnRight_MouseLeftButtonDown);
      btnRight.MouseEnter += new MouseEventHandler(btnRight_MouseEnter);
      btnRight.MouseLeave += new MouseEventHandler(btnRight_MouseLeave);

      Product testProduct = new Product();
      
      testProduct.AddProductImage("Image001.jpg");
      testProduct.AddProductImage("Image002.jpg");
      testProduct.AddProductImage("Image003.jpg");
      testProduct.AddProductImage("Image004.jpg");

      uxSlideShow.ItemsSource = testProduct.Images;
    }

    void SetNextPattern()
    {
      PatternList list = Application.Current.Resources["PatternList"] as PatternList;
      uxSlideShow.Pattern = list.GetNextPattern();
    }

    void btnRight_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      SetNextPattern();

      uxSlideShow.ShowNext();
    }
    void btnLeft_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      SetNextPattern();

      uxSlideShow.ShowPrevious();
    }

    void btnRight_MouseLeave(object sender, MouseEventArgs e)
    {
      (sender as TextBlock).Foreground = new SolidColorBrush(Colors.White);
    }
    void btnRight_MouseEnter(object sender, MouseEventArgs e)
    {
      (sender as TextBlock).Foreground = new SolidColorBrush(Colors.Red);
    }
  }
}
